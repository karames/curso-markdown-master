# Formato del texto

Resaltar texto ya sea poniendolo en **negritas** o *cursiva* es muy útil, en _Markdown_ para hacer esto se utilizan los caracteres \* y \_.

Es muy simple, para colocar una cadena de texto en cursiva simplemente se pone entre dos \* o dos \_, y si se quiere que este en negritas estos se ponen dobles, es decir se encierra ente \*\* o entre \_\_, estos también pueden anidarse para poder usarse uno dentro de otro, la siguiente tabla da algunos ejemplos.

| Ejemplo                        | Código                           |
| :----------------------------- | :--------------------------------|
| __negrita__                    | `__negrita__`                    |
| *cursiva*                      | `*cursiva*`                      |
| **_ambas_**                    | `**_ambas_**`                    |
| *texto **anidado** de ejemplo* | `*texto **anidado** de ejemplo*` |