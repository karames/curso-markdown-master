# Citas

La creación de citas en *Markdown* es muy sencillo, simplemente se debe poner el carácter de mayor que \(**>**\) antes del texto de la cita, por ejemplo la siguiente cita:

> Y yo, soy Ironman – Tony Stark

En código seria así:

```
> Y yo, soy Ironman – Tony Stark
```

Si se quieren crear citas anidadas, en el siguiente nivel de la cita se debe agregar otro **>**.

Este seria el ejemplo de una cita anidada en otra:

> Esto es una cita normal
>> Esta ya seria una cita anidada

```
> Esto es una cita normal
>> Esta ya seria una cita anidada
```